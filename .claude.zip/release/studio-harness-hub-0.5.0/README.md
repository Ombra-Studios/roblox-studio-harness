# Hub de echipă pe server Ubuntu

Hub-ul (`scripts/team_hub.py`) este Python 3.10+ fără dependențe. Ține în memorie membrii, sesiunile, claims-urile și jurnalul; la repornire daemon-urile se reînregistrează singure și retrimit evenimentele. Pe server nu ajunge nicio credențială Claude, ChatGPT sau Roblox, doar tokenul echipei.

## Instalare ca serviciu systemd

Pe server, cu repo-ul copiat (de exemplu `git clone` sau `scp`):

```bash
sudo bash deploy/ubuntu/install.sh
sudo cat /var/lib/studio-harness/team-token
```

Scriptul creează utilizatorul de sistem `studio-harness`, copiază `team_hub.py`, `claims.py` și `local_state.py` în `/opt/studio-harness`, pune starea în `/var/lib/studio-harness` (doar utilizatorul serviciului o poate citi), instalează și pornește `studio-harness-hub.service` cu izolare systemd (`ProtectSystem=strict`, `NoNewPrivileges`, fără acces la `/home`).

Implicit hub-ul ascultă doar pe `127.0.0.1:34880`, ca să fie expus exclusiv prin HTTPS. Pentru un server aflat doar în LAN, fără proxy: `sudo bash deploy/ubuntu/install.sh --public` și `sudo ufw allow 34880/tcp`.

## HTTPS (recomandat pentru orice acces din afara LAN-ului)

Alege una dintre variante și pune un domeniu (record A/AAAA) către server.

**Caddy** (certificat automat):

```bash
sudo apt install caddy
sudo cp deploy/ubuntu/Caddyfile /etc/caddy/Caddyfile   # editează domeniul
sudo systemctl reload caddy
sudo ufw allow 80/tcp && sudo ufw allow 443/tcp
```

**nginx + certbot**:

```bash
sudo apt install nginx certbot python3-certbot-nginx
sudo cp deploy/ubuntu/nginx-hub.conf /etc/nginx/sites-available/studio-harness-hub   # editează domeniul
sudo ln -s /etc/nginx/sites-available/studio-harness-hub /etc/nginx/sites-enabled/
sudo certbot --nginx -d hub.exemplu.ro
sudo nginx -t && sudo systemctl reload nginx
```

Verificare: `curl https://hub.exemplu.ro/healthz` → `{"ok": true, "version": "0.5.0"}`. `/healthz` nu cere token și nu dezvăluie nimic despre echipă; toate celelalte rute cer antetul `X-Studio-Harness-Team`.

## Configurarea developerilor

Pe fiecare PC cu Roblox Studio, în `%LOCALAPPDATA%\StudioHarness\team.json`:

```json
{"developer": "ana", "hub_url": "https://hub.exemplu.ro", "team_token": "<conținutul lui team-token>"}
```

Daemon-ul citește fișierul la pornire (repornește sesiunea Claude Code cu pluginul sau `Start-Daemon.cmd`). În hub-ul din Studio, secțiunea Echipă arată `connected` și membrii online.

## Operare

- Jurnal: `journalctl -u studio-harness-hub -f` (înregistrări, membri offline, erori; niciodată tokenul, decât cu `--show-token`).
- Repornire / oprire: `sudo systemctl restart studio-harness-hub`, `sudo systemctl stop studio-harness-hub`.
- Rotirea tokenului: `sudo rm /var/lib/studio-harness/team-token && sudo systemctl restart studio-harness-hub`, apoi distribuie noul token. Alternativ, un token fix prin `STUDIO_HARNESS_TEAM_TOKEN` în `Environment=` sau `--team-token`.
- Actualizare: copiază noile `scripts/team_hub.py`, `claims.py`, `local_state.py` peste `/opt/studio-harness` și repornește serviciul (sau rulează din nou `install.sh`).
- Dezinstalare: `sudo systemctl disable --now studio-harness-hub && sudo rm /etc/systemd/system/studio-harness-hub.service && sudo rm -r /opt/studio-harness /var/lib/studio-harness && sudo userdel studio-harness`.

## Docker (alternativă)

```bash
docker build -f deploy/ubuntu/Dockerfile -t studio-harness-hub .
docker run -d --name studio-harness-hub --restart unless-stopped -p 127.0.0.1:34880:34880 -v studio-harness-hub:/data studio-harness-hub
docker exec studio-harness-hub cat /data/team-token
```

Portul este legat doar pe `127.0.0.1`; pune Caddy sau nginx în față ca mai sus.

## Limite

- Starea este în memorie: o repornire pierde claims-urile și jurnalul; daemon-urile se reînregistrează în câteva secunde și retrimit evenimentele sesiunilor active.
- Tokenul echipei este unic pentru toată echipa (tokenuri per developer: faza 3).
- Un membru fără sync de 60 s este marcat offline și claims-urile lui sunt eliberate; peste internet, o întrerupere mai lungă de un minut are acest efect.
