#!/usr/bin/env bash
# Instalează hub-ul de echipă Studio Harness ca serviciu systemd pe Ubuntu (22.04+ / 24.04+).
# Rulează ca root din directorul repo-ului: sudo bash deploy/ubuntu/install.sh [--public] [--port 34880]
set -euo pipefail

LISTEN="127.0.0.1"
PORT="34880"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --public) LISTEN="0.0.0.0"; shift ;;
    --port) PORT="${2:?--port cere o valoare}"; shift 2 ;;
    -h|--help) sed -n '2,3p' "$0"; exit 0 ;;
    *) echo "Opțiune necunoscută: $1" >&2; exit 2 ;;
  esac
done

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Rulează cu sudo." >&2
  exit 1
fi

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Funcționează atât din repo (deploy/ubuntu/ + scripts/) cât și din pachetul de hosting (deploy/ + scripts/).
if [[ -f "$HERE/../scripts/team_hub.py" ]]; then
  REPO="$(cd "$HERE/.." && pwd)"
else
  REPO="$(cd "$HERE/../.." && pwd)"
fi
APP_DIR="/opt/studio-harness"
STATE_DIR="/var/lib/studio-harness"
SERVICE="studio-harness-hub"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Instalez python3..."
  apt-get update -qq && apt-get install -y -qq python3
fi
python3 - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("Este necesar Python 3.10 sau mai nou (Ubuntu 22.04+).")
PY

if ! id -u studio-harness >/dev/null 2>&1; then
  useradd --system --home-dir "$STATE_DIR" --shell /usr/sbin/nologin studio-harness
fi

install -d -m 0755 "$APP_DIR"
for file in team_hub.py claims.py local_state.py; do
  install -m 0644 "$REPO/scripts/$file" "$APP_DIR/$file"
done
install -m 0644 "$HERE/README.md" "$APP_DIR/README.md"
install -d -m 0700 -o studio-harness -g studio-harness "$STATE_DIR"

sed -e "s|--listen 127.0.0.1|--listen $LISTEN|" -e "s|--port 34880|--port $PORT|" \
  "$HERE/$SERVICE.service" > "/etc/systemd/system/$SERVICE.service"
systemctl daemon-reload
systemctl enable --now "$SERVICE"

for _ in $(seq 1 20); do
  if [[ -s "$STATE_DIR/team-token" ]]; then break; fi
  sleep 0.5
done
if ! systemctl is-active --quiet "$SERVICE"; then
  echo "Serviciul nu a pornit; vezi: journalctl -u $SERVICE -n 50" >&2
  exit 1
fi
if command -v curl >/dev/null 2>&1; then
  curl -fsS "http://127.0.0.1:$PORT/healthz" >/dev/null && echo "healthz: OK"
fi

echo
echo "Hub instalat și pornit: $SERVICE ascultă pe $LISTEN:$PORT"
echo "Tokenul echipei (secret partajat, nu credențială AI/Roblox):"
echo "  sudo cat $STATE_DIR/team-token"
if [[ "$LISTEN" == "127.0.0.1" ]]; then
  echo "Hub-ul este accesibil doar local. Pune un reverse proxy HTTPS în față (deploy/ubuntu/Caddyfile sau nginx-hub.conf),"
  echo "apoi developerii folosesc hub_url = https://<domeniul-tău> în team.json."
else
  echo "Hub-ul ascultă public pe portul $PORT (HTTP). Recomandat doar în LAN; pentru internet folosește HTTPS prin proxy."
  echo "Firewall: sudo ufw allow $PORT/tcp"
fi
echo "Jurnal: journalctl -u $SERVICE -f"
