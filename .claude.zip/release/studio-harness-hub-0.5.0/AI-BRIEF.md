# Brief pentru asistentul AI care face hosting-ul

Acest fișier este scris pentru un agent AI (Claude Code, Codex sau similar) care primește pachetul `studio-harness-hub` și trebuie să îl instaleze pe un server Ubuntu. Citește-l integral înainte de prima comandă.

## Ce este serviciul

- Un singur proces Python 3.10+ fără dependențe: `scripts/team_hub.py`. Este „hub-ul de echipă” al pluginului Studio Harness pentru Roblox Studio: developerii au pe PC-urile lor un daemon local care se înregistrează la hub, trimite la ~1,5 s sesiunile agenților lor AI și primește tabla comună (cine lucrează, ce zone ale scenei sunt revendicate, jurnalul modificărilor).
- Hub-ul ține totul **în memorie**. La repornire, daemon-urile se reînregistrează singure în câteva secunde. Nu are bază de date și nu scrie nimic în afara directorului de stare (doar fișierul `team-token`).
- Pe server **nu ajung credențiale** Claude, ChatGPT sau Roblox. Singurul secret este **tokenul echipei**, un text de 43 de caractere creat de hub la prima pornire.
- Trafic: cereri HTTP JSON mici (câțiva KB) de la fiecare PC de developer, la 1,5–5 s; `POST /team/claims/wait` poate ține o conexiune deschisă până la 60 s. Consum neglijabil: câteva zeci de MB RAM.

## Ce trebuie să obții la final

1. `studio-harness-hub.service` activ, pornit la boot, ascultând pe `127.0.0.1:34880`.
2. HTTPS public pe un domeniu (de exemplu `hub.exemplu.ro`) prin Caddy sau nginx, care face proxy către `127.0.0.1:34880`.
3. `curl https://hub.exemplu.ro/healthz` → `{"ok": true, "version": "0.5.0"}`.
4. Tokenul echipei transmis persoanei care a trimis pachetul **printr-un canal sigur**, împreună cu URL-ul.

## Pași

```bash
# 1. Copiază pachetul pe server și dezarhivează-l (de exemplu în /root/studio-harness-hub)
cd studio-harness-hub
sudo bash deploy/install.sh            # creează utilizatorul, /opt/studio-harness, /var/lib/studio-harness, serviciul
sudo systemctl status studio-harness-hub --no-pager
curl -s http://127.0.0.1:34880/healthz  # trebuie {"ok": true, "version": "0.5.0"}

# 2. HTTPS — varianta Caddy (recomandată, certificat automat)
sudo apt install -y caddy
sudo sed -i 's/hub.exemplu.ro/<DOMENIUL-REAL>/' deploy/Caddyfile
sudo cp deploy/Caddyfile /etc/caddy/Caddyfile
sudo systemctl reload caddy
sudo ufw allow 80/tcp && sudo ufw allow 443/tcp   # dacă ufw este activ

#    Varianta nginx: deploy/nginx-hub.conf + certbot (vezi README.md)

# 3. Verificare din afară
curl -s https://<DOMENIUL-REAL>/healthz
curl -s -o /dev/null -w "%{http_code}\n" https://<DOMENIUL-REAL>/team/status   # 401 fără token = corect

# 4. Tokenul
sudo cat /var/lib/studio-harness/team-token
```

Cerințe prealabile: un record DNS A/AAAA pentru domeniu către server, porturile 80 și 443 deschise. Portul 34880 **nu** se deschide public.

## Reguli de siguranță

- Nu lipi tokenul în tichete, chat-uri, commit-uri sau loguri. Transmite-l prin canalul convenit cu solicitantul (manager de parole, mesaj efemer). Hub-ul nu îl scrie în jurnal decât dacă este pornit cu `--show-token`.
- Nu expune portul 34880 în afara serverului. Fără HTTPS, tokenul ar circula în clar.
- Nu modifica `team_hub.py`, `claims.py` sau `local_state.py`; dacă ceva nu merge, raportează în loc să „repari” protocolul.
- Nu rula serviciul ca root și nu schimba `User=studio-harness`. Dacă systemd refuză pornirea din cauza izolării, singura linie pe care o poți scoate din unit este `MemoryDenyWriteExecute=true`; raportează că ai făcut-o.
- Dacă vrei un token stabil ales de tine (de exemplu dintr-un manager de secrete), pune-l în unit ca `Environment=STUDIO_HARNESS_TEAM_TOKEN=...` (16–512 de caractere, fără spații) și repornește serviciul.

## Verificări de acceptanță

| Verificare | Așteptat |
| --- | --- |
| `systemctl is-active studio-harness-hub` | `active` |
| `curl -s http://127.0.0.1:34880/healthz` | `{"ok": true, "version": "0.5.0"}` |
| `curl -s https://<domeniu>/healthz` | același răspuns, prin HTTPS |
| `curl -s -o /dev/null -w "%{http_code}" https://<domeniu>/team/status` | `401` |
| `curl -s -H "X-Studio-Harness-Team: $(sudo cat /var/lib/studio-harness/team-token)" https://<domeniu>/team/status` | `{"ok": true, "version": "0.5.0", "hub_id": "...", "members": []}` |
| `sudo journalctl -u studio-harness-hub -n 20` | linia „ascultă pe http://127.0.0.1:34880”, fără token |
| `sudo ss -ltnp \| grep 34880` | legat doar pe `127.0.0.1` |

## Depanare

- **Serviciul nu pornește**: `sudo journalctl -u studio-harness-hub -n 50`. Cauze tipice: Python sub 3.10 (`python3 --version`; Ubuntu 22.04+ este ok), portul 34880 ocupat (`sudo ss -ltnp | grep 34880`), directorul de stare fără drepturi (`sudo chown -R studio-harness:studio-harness /var/lib/studio-harness`).
- **`healthz` merge local, dar nu prin HTTPS**: DNS-ul nu indică serverul, porturile 80/443 închise, sau domeniul din Caddyfile/nginx nu a fost înlocuit. `sudo journalctl -u caddy -n 50` sau `sudo nginx -t`.
- **Developerii văd „Hub-ul echipei nu răspunde”**: hub-ul este oprit sau proxy-ul taie conexiunile lungi; timeout-ul de citire al proxy-ului trebuie să fie ≥ 90 s (este deja în fișierele livrate).
- **Rotirea tokenului**: `sudo rm /var/lib/studio-harness/team-token && sudo systemctl restart studio-harness-hub`, apoi distribuie noul token.
- **Actualizare**: dezarhivează noul pachet și rulează din nou `sudo bash deploy/install.sh`; serviciul este repornit, tokenul se păstrează.

## Referință rapidă a API-ului (doar pentru diagnostic)

Toate rutele în afară de `/healthz` cer antetul `X-Studio-Harness-Team: <token>` și JSON. `GET /team/status` (membri online/offline), `POST /team/register`, `POST /team/sync`, `POST /team/claims/claim|release|touch|wait`. Cererile cu antet `Origin` (din browser) sunt refuzate cu 403. Nu există interfață web: tabla se vede în Roblox Studio, pe PC-urile developerilor.

## Ce raportezi la final

URL-ul HTTPS, rezultatul verificărilor de acceptanță, varianta de proxy folosită, orice linie scoasă din unitatea systemd și canalul prin care ai transmis tokenul. Nu include tokenul în raport.
