"""Hub de echipă: un proces per echipă. Tablă comună, claims atomice, jurnal global. Fără credențiale AI/Roblox."""

from __future__ import annotations

import argparse
import copy
import hmac
import json
import os
import signal
import sys
import threading
import time
import uuid
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

sys.path.insert(0, str(Path(__file__).resolve().parent))
from claims import ClaimTable, display, normalize  # noqa: E402
from local_state import ensure_team_token, state_dir  # noqa: E402

VERSION = "0.5.0"
OFFLINE_SECONDS = 60
SESSION_RETENTION = 600
MAX_EVENTS = 1024
MAX_JOURNAL = 2000
MAX_JOURNAL_PAGE = 200
MAX_SYNC_SESSIONS = 64
MAX_WAIT = 60
MAX_BODY = 4 * 1024 * 1024
TERMINAL_STATES = {"completed", "failed", "cancelled"}
META_FIELDS = ("job_id", "kind", "provider", "developer", "name", "state", "studio_id", "cwd", "started",
               "last_activity", "pending_approval", "claims")


class HubError(RuntimeError):
    def __init__(self, message: str, status: int = 400, payload: dict[str, Any] | None = None):
        super().__init__(message)
        self.status = status
        self.payload = payload or {}


def _text(value: Any, limit: int, name: str, required: bool = True) -> str | None:
    if value is None and not required:
        return None
    if not isinstance(value, str) or (required and not value.strip()) or len(value) > limit:
        raise HubError(f"Câmpul {name} este invalid.")
    return value


def log(message: str) -> None:
    """Jurnal pe stdout (journald/docker): fără tokenuri, fără conținutul sesiunilor."""
    print(time.strftime("%Y-%m-%d %H:%M:%S") + " " + message, flush=True)


class TeamHub:
    def __init__(self, token: str, clock: Any = time.time, logger: Any = log):
        self.token = token
        self.clock = clock
        self.log = logger
        self.hub_id = uuid.uuid4().hex
        self.lock = threading.RLock()
        self.members: dict[str, dict[str, Any]] = {}
        self.sessions: dict[str, dict[str, Any]] = {}
        self.claims = ClaimTable(clock=clock)
        self.journal: deque[dict[str, Any]] = deque(maxlen=MAX_JOURNAL)
        self.journal_seq = 0

    # ----- membri -----

    def _member_rows(self, now: float) -> list[dict[str, Any]]:
        return [{"member_id": member["member_id"], "developer": member["developer"], "machine": member["machine"],
                 "online": now - member["last_seen"] < OFFLINE_SECONDS, "last_seen": member["last_seen"]}
                for member in sorted(self.members.values(), key=lambda item: (item["developer"], item["machine"]))]

    def status(self) -> dict[str, Any]:
        now = self.clock()
        with self.lock:
            self._reap(now)
            return {"ok": True, "version": VERSION, "hub_id": self.hub_id, "members": self._member_rows(now)}

    def register(self, body: dict[str, Any]) -> dict[str, Any]:
        developer = _text(body.get("developer"), 64, "developer")
        machine = _text(body.get("machine"), 64, "machine")
        bridge_id = _text(body.get("bridge_id"), 64, "bridge_id")
        version = _text(body.get("version"), 32, "version", required=False) or ""
        now = self.clock()
        with self.lock:
            # Aceeași mașină + același developer reînregistrată după repornire își înlocuiește membrul vechi.
            for old_id, member in list(self.members.items()):
                if member["developer"] == developer and member["machine"] == machine:
                    self._forget_member(old_id)
            member_id = uuid.uuid4().hex
            self.members[member_id] = {"member_id": member_id, "developer": developer, "machine": machine,
                                       "bridge_id": bridge_id, "version": version, "last_seen": now}
            self.log("membru înregistrat: " + developer + " @ " + machine + " (daemon " + (version or "?") + ")")
            return {"ok": True, "hub_id": self.hub_id, "member_id": member_id}

    def _member(self, member_id: Any) -> dict[str, Any]:
        member = self.members.get(member_id) if isinstance(member_id, str) else None
        if not member:
            raise HubError("Membru necunoscut; reînregistrează-te.", 404)
        return member

    def _forget_member(self, member_id: str) -> None:
        for job_id, entry in list(self.sessions.items()):
            if entry["member_id"] == member_id:
                self.claims.release(job_id)
                del self.sessions[job_id]
        self.members.pop(member_id, None)

    def _reap(self, now: float) -> None:
        for member in self.members.values():
            offline = now - member["last_seen"] >= OFFLINE_SECONDS
            if offline and not member.get("reaped"):
                member["reaped"] = True
                self.log("membru offline: " + member["developer"] + " @ " + member["machine"] + "; claims-urile lui au fost eliberate")
                for job_id, entry in self.sessions.items():
                    if entry["member_id"] == member["member_id"]:
                        self.claims.release(job_id)
                        if entry["meta"]["state"] not in TERMINAL_STATES:
                            entry["meta"]["state"] = "lost"
                            entry["closed_at"] = now
        for job_id, entry in list(self.sessions.items()):
            if entry.get("closed_at") is not None and now - entry["closed_at"] > SESSION_RETENTION:
                self.claims.release(job_id)
                del self.sessions[job_id]

    # ----- sync -----

    def sync(self, body: dict[str, Any]) -> dict[str, Any]:
        now = self.clock()
        with self.lock:
            member = self._member(body.get("member_id"))
            member["last_seen"] = now
            member.pop("reaped", None)
            sessions = body.get("sessions", [])
            if not isinstance(sessions, list) or len(sessions) > MAX_SYNC_SESSIONS:
                raise HubError("sessions trebuie să fie o listă de cel mult 64 de sesiuni.")
            for row in sessions:
                if not isinstance(row, dict):
                    raise HubError("Sesiune invalidă.")
                job_id = _text(row.get("job_id"), 128, "job_id")
                entry = self.sessions.get(job_id)
                if entry and entry["member_id"] != member["member_id"]:
                    continue
                meta = {field: copy.deepcopy(row.get(field)) for field in META_FIELDS}
                meta["developer"] = member["developer"]
                meta["machine"] = member["machine"]
                meta["member_id"] = member["member_id"]
                meta["remote"] = True
                if entry is None:
                    entry = self.sessions[job_id] = {"member_id": member["member_id"], "meta": meta, "events": [], "closed_at": None}
                entry["meta"] = meta
                events = row.get("events", [])
                if not isinstance(events, list):
                    raise HubError("events trebuie să fie o listă.")
                last = entry["events"][-1]["seq"] if entry["events"] else 0
                for event in events:
                    if isinstance(event, dict) and isinstance(event.get("seq"), int) and not isinstance(event.get("seq"), bool) and event["seq"] > last:
                        entry["events"].append(copy.deepcopy(event))
                        last = event["seq"]
                if len(entry["events"]) > MAX_EVENTS:
                    del entry["events"][:len(entry["events"]) - MAX_EVENTS]
                if meta.get("state") in TERMINAL_STATES:
                    if entry["closed_at"] is None:
                        entry["closed_at"] = now
                else:
                    entry["closed_at"] = None
            touched = body.get("touch", [])
            if isinstance(touched, list):
                for job_id in touched:
                    if isinstance(job_id, str):
                        self.claims.touch(job_id)
            for item in body.get("journal", []) if isinstance(body.get("journal"), list) else []:
                if not isinstance(item, dict):
                    continue
                self.journal_seq += 1
                entry_row = {key: copy.deepcopy(item.get(key)) for key in ("time", "job_id", "provider", "tool", "paths", "summary")}
                entry_row.update(seq=self.journal_seq, developer=member["developer"], machine=member["machine"])
                self.journal.append(entry_row)
            self._reap(now)
            want = body.get("want", {})
            events: dict[str, list[dict[str, Any]]] = {}
            if isinstance(want, dict):
                for job_id, after in list(want.items())[:MAX_SYNC_SESSIONS]:
                    entry = self.sessions.get(job_id)
                    if entry and entry["member_id"] != member["member_id"] and isinstance(after, int) and not isinstance(after, bool):
                        events[job_id] = [copy.deepcopy(event) for event in entry["events"] if event["seq"] > after]
            journal_after = body.get("journal_after", 0)
            if not isinstance(journal_after, int) or isinstance(journal_after, bool) or journal_after < 0:
                journal_after = 0
            journal = [copy.deepcopy(row) for row in self.journal if row["seq"] > journal_after][:MAX_JOURNAL_PAGE]
            others = [copy.deepcopy(entry["meta"]) for entry in self.sessions.values() if entry["member_id"] != member["member_id"]]
            others.sort(key=lambda row: row.get("started") or 0)
            return {"ok": True, "hub_id": self.hub_id, "members": self._member_rows(now), "sessions": others,
                    "events": events, "claims": self.claims.snapshot(), "journal": journal, "journal_seq": self.journal_seq}

    # ----- claims -----

    def _held(self, job_id: str) -> list[str]:
        return [display(claim.path) for claim in self.claims.held_by(job_id)]

    def claim(self, body: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            member = self._member(body.get("member_id"))
            job_id = _text(body.get("job_id"), 128, "job_id")
            paths = body.get("paths")
            if not isinstance(paths, list) or not paths or len(paths) > 32 or any(not isinstance(path, str) for path in paths):
                raise HubError("paths trebuie să fie o listă de 1-32 căi text.")
            reason = body.get("reason", "")
            if not isinstance(reason, str):
                raise HubError("reason trebuie să fie text.")
            try:
                added, conflicts = self.claims.claim(job_id, member["developer"], paths, reason)
            except ValueError as error:
                raise HubError(str(error)) from None
            if conflicts:
                raise HubError("Conflict de claim.", 409, {"conflicts": conflicts})
            return {"ok": True, "claimed": [display(claim.path) for claim in added], "held": self._held(job_id)}

    def release(self, body: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            self._member(body.get("member_id"))
            job_id = _text(body.get("job_id"), 128, "job_id")
            paths = body.get("paths")
            if paths is not None and (not isinstance(paths, list) or any(not isinstance(path, str) for path in paths)):
                raise HubError("paths trebuie să fie o listă de texte.")
            try:
                released = self.claims.release(job_id, paths)
            except ValueError as error:
                raise HubError(str(error)) from None
            return {"ok": True, "released": [display(claim.path) for claim in released], "held": self._held(job_id)}

    def touch(self, body: dict[str, Any]) -> dict[str, Any]:
        with self.lock:
            self._member(body.get("member_id"))
            job_id = _text(body.get("job_id"), 128, "job_id")
            self.claims.touch(job_id)
            return {"ok": True, "held": self._held(job_id)}

    def wait(self, body: dict[str, Any]) -> dict[str, Any]:
        path = body.get("path")
        timeout = body.get("timeout_seconds", MAX_WAIT)
        if not isinstance(path, str) or not isinstance(timeout, (int, float)) or isinstance(timeout, bool):
            raise HubError("wait cere path (text) și timeout_seconds (număr).")
        try:
            target = normalize(path)
        except ValueError as error:
            raise HubError(str(error)) from None
        free = self.claims.wait_free(target, min(max(float(timeout), 0.0), MAX_WAIT))
        return {"ok": True, "free": free}


class HubHandler(BaseHTTPRequestHandler):
    server_version = "StudioHarnessHub/0.5"

    def log_message(self, *_: Any) -> None:
        pass

    def _json(self, status: int, value: Any) -> None:
        self._discard_body()
        data = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def _discard_body(self) -> None:
        """Consumă corpul necitit înainte de un refuz timpuriu (401/403/404): altfel, pe Windows, închiderea conexiunii cu date necitite poate anula răspunsul și clientul pierde JSON-ul."""
        if getattr(self, "body_consumed", False):
            return
        self.body_consumed = True
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return
        if 0 < length <= MAX_BODY:
            self.rfile.read(length)

    def _body(self) -> dict[str, Any]:
        if self.headers.get_content_type() != "application/json":
            raise HubError("Este necesar Content-Type application/json.", 415)
        try:
            length = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            raise HubError("Content-Length invalid.") from None
        if not 0 <= length <= MAX_BODY:
            raise HubError("Corpul cererii lipsește sau depășește limita.", 413)
        self.body_consumed = True
        try:
            value = json.loads(self.rfile.read(length))
        except (ValueError, UnicodeDecodeError):
            raise HubError("JSON invalid.") from None
        if not isinstance(value, dict):
            raise HubError("Corpul cererii trebuie să fie un obiect JSON.")
        return value

    def _handle(self) -> None:
        hub: TeamHub = self.server.hub
        try:
            if self.headers.get("Origin"):
                raise HubError("Accesul din pagini web nu este permis.", 403)
            path = urlsplit(self.path).path
            if self.command == "GET" and path == "/healthz":
                # Pentru reverse proxy și monitorizare: fără token și fără date despre echipă.
                self._json(200, {"ok": True, "version": VERSION})
                return
            if not hmac.compare_digest(hub.token.encode("utf-8"), self.headers.get("X-Studio-Harness-Team", "").encode("utf-8")):
                raise HubError("Tokenul echipei este invalid.", 401)
            if self.command == "GET" and path == "/team/status":
                result = hub.status()
            elif self.command == "POST" and path == "/team/register":
                result = hub.register(self._body())
            elif self.command == "POST" and path == "/team/sync":
                result = hub.sync(self._body())
            elif self.command == "POST" and path == "/team/claims/claim":
                result = hub.claim(self._body())
            elif self.command == "POST" and path == "/team/claims/release":
                result = hub.release(self._body())
            elif self.command == "POST" and path == "/team/claims/touch":
                result = hub.touch(self._body())
            elif self.command == "POST" and path == "/team/claims/wait":
                result = hub.wait(self._body())
            else:
                raise HubError("Rută inexistentă.", 404)
            self._json(200, result)
        except HubError as error:
            self._json(error.status, {"ok": False, "error": str(error), **error.payload})
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception as error:
            hub.log("eroare internă la " + self.command + " " + self.path.split("?")[0] + ": " + type(error).__name__)
            self._json(500, {"ok": False, "error": "Eroare internă a hub-ului."})

    def do_GET(self) -> None:
        self._handle()

    def do_POST(self) -> None:
        self._handle()

    def do_OPTIONS(self) -> None:
        self._json(403, {"ok": False, "error": "Accesul din pagini web nu este permis."})


class HubServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, listen: str, port: int, hub: TeamHub):
        super().__init__((listen, port), HubHandler)
        self.hub = hub

    def get_request(self):
        connection, address = super().get_request()
        connection.settimeout(120)
        return connection, address


def main() -> int:
    parser = argparse.ArgumentParser(description="Hub de echipă Studio Harness: tablă comună, claims și jurnal pentru mai mulți developeri.")
    parser.add_argument("--listen", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=34880)
    parser.add_argument("--team-token", default=None, help="Tokenul echipei; altfel STUDIO_HARNESS_TEAM_TOKEN sau fișierul team-token din --state-dir.")
    parser.add_argument("--state-dir", type=Path, default=None)
    parser.add_argument("--show-token", action="store_true", help="Afișează tokenul la pornire (implicit doar calea fișierului, ca jurnalul serverului să nu îl conțină).")
    options = parser.parse_args()
    if not 1024 <= options.port <= 65535:
        parser.error("Portul trebuie să fie între 1024 și 65535.")
    state = options.state_dir or state_dir()
    token = options.team_token or os.environ.get("STUDIO_HARNESS_TEAM_TOKEN") or ensure_team_token(state)
    if len(token) < 16 or len(token) > 512 or any(character.isspace() for character in token):
        parser.error("Tokenul echipei trebuie să aibă 16-512 de caractere, fără spații.")
    server = HubServer(options.listen, options.port, TeamHub(token))
    url = "http://" + options.listen + ":" + str(server.server_address[1])
    log("Studio Harness hub de echipă " + VERSION + " ascultă pe " + url + " (stare: " + str(state) + ")")
    if options.show_token:
        log("Token de echipă (secret partajat al echipei, nu credențială AI/Roblox): " + token)
    elif options.team_token or os.environ.get("STUDIO_HARNESS_TEAM_TOKEN"):
        log("Tokenul echipei vine din --team-token / STUDIO_HARNESS_TEAM_TOKEN (pornește cu --show-token ca să îl afișezi)")
    else:
        log("Tokenul echipei: " + str(state / "team-token") + " (pornește cu --show-token ca să îl afișezi)")
    log("Fiecare developer pune în %LOCALAPPDATA%\\StudioHarness\\team.json: {\"developer\": \"nume\", \"hub_url\": \"https://<hub>\", \"team_token\": \"...\"}")

    def stop(*_: Any) -> None:
        raise KeyboardInterrupt

    for name in ("SIGTERM", "SIGINT"):
        if hasattr(signal, name):
            signal.signal(getattr(signal, name), stop)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        log("oprire cerută; hub-ul se închide")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    raise SystemExit(main())
