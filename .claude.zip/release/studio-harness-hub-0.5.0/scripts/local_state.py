"""Stare locală per mașină: cod de asociere stabil, numele developerului, directorul daemon-ului."""

from __future__ import annotations

import json
import os
import re
import secrets
from pathlib import Path

TOKEN_PATTERN = re.compile(r"[A-Za-z0-9_\-]{16,512}")
NAME_PATTERN = re.compile(r"[^\x00-\x1f\x7f]{1,64}")


def state_dir(environ: dict[str, str] | None = None, platform: str | None = None) -> Path:
    env = os.environ if environ is None else environ
    override = env.get("STUDIO_HARNESS_STATE_DIR")
    if override:
        return Path(override)
    if (platform or os.name) == "nt":
        local = env.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(local) / "StudioHarness"
    # Linux/macOS (hub-ul găzduit pe server): XDG_STATE_HOME sau ~/.local/state.
    base = env.get("XDG_STATE_HOME") or str(Path(env.get("HOME") or Path.home()) / ".local" / "state")
    return Path(base) / "studio-harness"


def ensure_local_token(directory: Path) -> str:
    """Codul local este creat o singură dată și refolosit de daemon, shim, hook-uri și plugin."""
    return ensure_token_file(directory / "local-token")


def ensure_team_token(directory: Path) -> str:
    """Tokenul echipei, creat de hub la prima pornire; secret partajat, nu credențială AI/Roblox."""
    return ensure_token_file(directory / "team-token")


def ensure_token_file(path: Path) -> str:
    directory = path.parent
    directory.mkdir(parents=True, exist_ok=True)
    for _ in range(3):
        try:
            text = path.read_text(encoding="utf-8").strip()
        except FileNotFoundError:
            text = None
        if text is not None and TOKEN_PATTERN.fullmatch(text):
            return text
        candidate = secrets.token_urlsafe(32)
        try:
            mode = "w" if text is not None else "x"
            with path.open(mode, encoding="utf-8") as stream:
                stream.write(candidate)
            if os.name != "nt":
                try:
                    os.chmod(path, 0o600)
                except OSError:
                    pass
            return candidate
        except FileExistsError:
            continue
    raise RuntimeError("Codul local de asociere nu poate fi creat.")


def read_local_token(directory: Path) -> str | None:
    try:
        text = (directory / "local-token").read_text(encoding="utf-8").strip()
    except OSError:
        return None
    return text if TOKEN_PATTERN.fullmatch(text) else None


def read_team(directory: Path) -> dict:
    try:
        value = json.loads((directory / "team.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def developer_name(directory: Path, environ: dict[str, str] | None = None) -> str:
    env = os.environ if environ is None else environ
    candidates = [read_team(directory).get("developer"), env.get("STUDIO_HARNESS_DEVELOPER"),
                  env.get("USERNAME"), env.get("USER")]
    for candidate in candidates:
        if isinstance(candidate, str) and NAME_PATTERN.fullmatch(candidate.strip()):
            return candidate.strip()
    return "developer"
